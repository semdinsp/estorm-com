ENV['RACK_ENV'] = 'test'
require "bundler/setup"
require 'bundler'
Bundler.require :default, :test
require "codeclimate-test-reporter"
CodeClimate::TestReporter.start

#gem 'rack-test'
require 'minitest/autorun'
require 'rack/test'
require 'nesta/env'
Nesta::Env.root = ::File.expand_path('.', ::File.dirname(__FILE__))

require 'nesta/app'



class TLLottoTest < Minitest::Test
  include Rack::Test::Methods

  def app
    Nesta::App
  end

  def test_first_pageworks
    puts "testing first page"
    get '/'
    #puts last_response.methods
    puts last_response
    assert last_response.ok?
    assert last_response.body.include? 'operational services on'
  end
  def test_another_pageworks
    puts "testing tickets page"
    get '/tickets'
    #puts last_response.methods
    assert last_response.ok?
    assert last_response.body.include? '4d'
  end

  def test_key_pages
     pagelist=["contact","balance","tickets", "index", "others","transfer","redeem"]
     puts "testing top level pages #{pagelist.inspect}"
     pagelist.each { |page| 
       puts "testing page: [#{page}]"
          get page
          assert last_response.ok?, "#{page} not found"
          #assert_equal last_response.body.includes? 'Ficonab Pte. Ltd.'
            }
   end
   def test_testpage
      pagelist=["test"]
      puts "testing test page level pages #{pagelist.inspect}"
      pagelist.each { |page| 
        puts "testing page: [#{page}]"
           get page
           assert last_response.ok?, "#{page} not found"
           #assert_equal last_response.body.includes? 'Ficonab Pte. Ltd.'
             }
    end
  
  
end
