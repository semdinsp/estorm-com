[![Build Status](https://magnum.travis-ci.com/semdinsp/estorm_lotto_web.png?token=fw5zxPYM6WV8YEvtmrxJ&branch=master)](https://magnum.travis-ci.com/semdinsp/estorm_lotto_web)
[![Code Climate](https://codeclimate.com/repos/52848aaec7f3a33db700b7b1/badges/f23c064085d9f64c0e40/gpa.png)](https://codeclimate.com/repos/52848aaec7f3a33db700b7b1/feed)
# Website for distributor terminals
They use nesta cms as a basic platform and haml for markdown.  Supporting multi language


There is a travis job running to validate the sites on every commit.  


