class User
  attr_accessor :identity
  def initiliaze
    #@identity='6590683565'
   # @password='test'
  end
  #def identity
  #  @identity
  # end
  def id
    @identity
  end
  def estorm_src
    @identity
  end
  def self.get(id)
    u=User.new
    u.identity=id
    u
  end
  def authenticate(attempted_password)
      wb=EstormLottoGem::WbBalance.new
      wb.set_host('estorm-sms.herokuapp.com')
      res=wb.get_session(self.identity,attempted_password)
      res
         #fix this
      if res!=nil and res.first!=nil and res.first['success']
       # Nesta::NestaBase.settings.estorm_src=self.identity
       # Nesta::App.settings.estorm_src=self.identity
        @password = attempted_password
        true
      else
        false
      end
    end
end