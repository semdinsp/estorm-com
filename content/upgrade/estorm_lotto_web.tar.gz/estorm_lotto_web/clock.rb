#!/usr/bin/env ruby
require 'i18n'
require 'i18n/backend/fallbacks'
#require 'sinatra/flash'
require 'estorm_lotto_gem'
require 'estorm_lotto_tools'
require 'system/getifaddrs'
require 'clockwork'

def get_draw_results(tickettype)
  wb=EstormLottoGem::WbDrawResults.new  
  wb.set_host(@basic.host)
  res=wb.get_results(@basic.identity,tickettype) 
  puts "results: #{res.inspect.to_s} basic: #{@basic.inspect.to_s}id #{@basic.identity} tt: #{tickettype} print #{@basic.printer}"  
  [res,wb]
end
def print_activity(tickettype,msg)
  puts "Starting job: #{msg}"
  begin
    res,wb=get_draw_results(tickettype)
    yield(res,wb)
   rescue Exception => e
     puts "Exception in #{msg} #{e.inspect}"
   end 
end

module Clockwork
  
puts "Starting clockwork module"
drawtime="21:18"
ramatime="10:00"
#drawtime[3]=['1','2'].sample
randigit=['1','3','6','7','9'].sample
drawtime[4]=randigit
ramatime[4]=randigit
puts "Print winners time #{drawtime} ramalan time #{ramatime}"

  @basic = EstormLottoTools::BasicConfig.new(nil,nil)
  
  # every(2.minutes, 'job test') { puts "Testing job test..."  }
  every(1.day, 'Print winners', :at => drawtime, :thread => true ) { 
    ['4d','3d','2d'].each { |tickettype|
     # ['4d','3d'].each { |tickettype|
     print_activity(tickettype,'print winners') {  |res,wb|   
               wb.print_results(res.first,@basic.identity,tickettype,  @basic.printer) if res!=nil and res.first!=nil and res.first['success']==true  
                           }
            }                    
    puts "...done." }
    every(1.day, 'Print ramalan', :at => ramatime, :thread => true ) { puts "Printing ramalan..."
      ['4d'].each { |tickettype|
       # ['4d','3d'].each { |tickettype|
            print_activity(tickettype,'print ramalan') { |res,wb|
                  wb.print_ramalan(res.first,@basic.identity,tickettype,@basic.printer)  if res!=nil and res.first!=nil and res.first['success']==true  
                        }
                }                    
      puts "...done." }
 
end