#!/usr/bin/env ruby
require 'i18n'
require 'i18n/backend/fallbacks'
#require 'sinatra/flash'
require 'estorm_lotto_gem'
require 'estorm_lotto_tools'
require 'system/getifaddrs'
require 'clockwork'





module Clockwork

puts "Starting clockwork module"
drawtime="21:"
ramatime="10:"
misctime=["15:","16:","17:"].sample
#drawtime[3]=['1','2'].sample
random_minute=(15..54).to_a.sample

drawtime="#{drawtime}#{random_minute}"
ramatime="#{ramatime}#{random_minute}"
misctime="#{misctime}#{random_minute}"


puts "Print winners time #{drawtime} ramalan time #{ramatime} misctime: #{misctime}"

 #  EstormLottoTools::WebClock.clock_for_client

  # every(2.minutes, 'job test') { puts "Testing job test..."  }
    every(1.day, 'Print winners', :at => drawtime, :thread => true ) { 
    # ['4d','3d','2d'].each { |tickettype|
        EstormLottoTools::WebClock.clock_action("print_results")              
        puts "...done." }
    every(1.day, 'Print ramalan', :at => ramatime, :thread => true ) { 
       EstormLottoTools::WebClock.clock_action("print_ramalan")                
      puts "...done." }
    every(1.day, 'Miscellaneous activities', :at => misctime, :thread => true ) { 
         EstormLottoTools::WebClock.miscellaneous_action("miscellanecous")                
          puts "...done." }
    
end