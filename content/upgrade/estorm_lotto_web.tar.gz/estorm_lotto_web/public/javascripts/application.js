(function() {
  var LuckyDip,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  LuckyDip = (function() {
    function LuckyDip(items) {
      this.multi_change = bind(this.multi_change, this);
      this.change = bind(this.change, this);
      this.nextItem = bind(this.nextItem, this);
      items.hide();
      this.items = items.toArray();
      if (this.items.length < 2) {
        throw "Instantiate LuckyDip with a set of 2 or more elements";
      }
      this.current = null;
    }

    LuckyDip.prototype.nextItem = function() {
      var index;
      index = Math.floor(Math.random() * this.items.length);
      if (this.current && index === $(this.items).index(this.current.get(0))) {
        return this.nextItem();
      } else {
        return $(this.items[index]);
      }
    };

    LuckyDip.prototype.change = function() {
      var show_next;
      show_next = (function(_this) {
        return function() {
          return _this.current = _this.nextItem().fadeIn('slow', function() {
            return setTimeout(_this.change, 8000);
          });
        };
      })(this);
      if (this.current) {
        return this.current.fadeOut('slow', function() {
          return show_next();
        });
      } else {
        return show_next();
      }
    };

    LuckyDip.prototype.multi_change = function(ld1, ld2) {
      ld1.change();
      return ld2.change();
    };

    return LuckyDip;

  })();

}).call(this);
