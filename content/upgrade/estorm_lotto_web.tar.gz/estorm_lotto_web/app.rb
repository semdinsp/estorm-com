require 'i18n'
require 'i18n/backend/fallbacks'
#require 'sinatra/flash'
require 'sinatra/base'
#require 'estorm_lotto_gem'
#require 'estorm_lotto_tools'
require 'rack-flash'
#require 'system/getifaddrs'
#puts "root is #{settings.root}"
#require 'sinatra/support/numeric'
require 'bundler'
Bundler.require
#require 'teds_lotto_gem'
#puts "load path is: #{$:}"
$: << File.expand_path('../', __FILE__)
$: << TedsLottoGem::Base.new.gem_file_directory
#puts "load path now is: #{$:}"

require 'nesta_base'
require 'nesta_core_base'
require 'nesta_wallet_routes'
require 'nesta_teds_balance'
require 'nesta_teds_config'
require 'nesta_teds_winners'
require 'nesta_teds_tickets'
require 'nesta_teds_retail'
require 'user_model'
module Nesta
  class App
    
    not_found do
       haml("404".to_sym)
    end
    register Sinatra::Numeric
    set :session_secret, "estorm-lotto-web"
    enable :sessions
    disable :ted_session
    use Rack::Flash
    use NestaWalletRoutes
    use NestaTedsBalance
    use NestaTedsConfig
    use NestaTedsWinners
    use NestaTedsTickets
    use NestaTedsRetail
    
    
    # register Sinatra::Flash
    before do
          #puts "session is #{session.inspect}"
          I18n.locale = session[:language] if session[:language]!=nil
          if request.path_info =~ Regexp.new('./$')
            redirect to(request.path_info.sub(Regexp.new('/$'), ''))
          end
          session['warden.user.default.key']=settings.estorm_src
          @current_user=User.get(settings.estorm_src)
        end
      
     configure do
       puts "in top level configure"
       @basic = EstormLottoTools::BasicConfig.new(File.dirname(__FILE__),'test.conf') if settings.environment==:test
       @basic = EstormLottoTools::BasicConfig.new(nil,nil) if settings.environment!=:test
        set :estorm_src, @basic.identity
        set :estorm_host, @basic.host  
        set :estorm_printer, @basic.printer
        set :estorm_modules, @basic.modules
        set :estorm_debug, false
        set :estorm_debug, true if @basic.identity=='6590683565'
        puts "src/identity: #{settings.estorm_src} host: #{settings.estorm_host} printer: #{settings.estorm_printer} modules #{settings.estorm_modules}"
        I18n::Backend::Simple.send(:include, I18n::Backend::Fallbacks)
        I18n.load_path=Dir[File.join(settings.root, 'config/locales', '*.yml')]
        I18n.backend.load_translations
        I18n.locale = 'en'
       puts "config at top level #{settings.inspect}"
      end
      post '/lang/:id' do
        lang=params[:id]
        if ['en','tet','ba'].include?(lang)
           puts "setting language to #{lang}"
           I18n.locale = lang 
           session[:language]=lang 
         end
        redirect to('/')
      end
   
      
      post '/future' do
        msg="#{params['future_type']} Functionality Coming soon"
          teds_flash_and_redirect(msg,:error,"/")
      end
    
    
     
      
  end
  class Page
    def heading
        regex = case @format
          when :mdown
            /^#\s*(.*?)(\s*#+|$)/
          when :haml
            /^\s*%h1\s+(.*)/
          when :textile
            /^\s*h1\.\s+(.*)/
          end
        markup =~ regex
        val=Regexp.last_match(1) or raise HeadingNotSet, "#{abspath} needs a heading"
        #puts "val is [#{val}]"
        val=eval(val[1..val.size]) if val[0]=='='
        val
      end
    end
end


