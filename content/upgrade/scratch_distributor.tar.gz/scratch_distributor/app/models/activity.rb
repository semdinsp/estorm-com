class Activity < ApplicationRecord
  belongs_to :user
  
  
  def self.build_activity(params,response,user)
    act = Activity.new
    act.params=params
    act.response=response
    act.user=user
    act
  end
  
  def print_credit_note(response)
    begin
    ['Credit Note Reprint'].each {  |title| 
        EstormLottoGem::MqttclientTms.tms_print_credit_note(response.inspect.to_s, Hwid.systemid,title,Setting.first.logo,Setting.first.printer_type,Setting.first.locale)
       }
     rescue Exception => e
       puts "Exception:  #{e.inspect}"
     end
  end
  
  def print_validation(response)
    begin
    ['TMS Receipt Reprint'].each {  |title| 
        EstormLottoGem::MqttclientTms.tms_print(response.inspect.to_s, Hwid.systemid,title,Setting.first.logo,Setting.first.printer_type,Setting.first.locale)
        sleep 1 
       }
    EstormLottoGem::MqttclientTms.tms_print_validation(response.inspect.to_s, Hwid.systemid,"Validation Summary",Setting.first.logo,Setting.first.printer_type,Setting.first.locale)
    rescue Exception => e
      puts "Exception:  #{e.inspect}"
    end
  end
  
  def self.print(activity)
    puts "printing #{activity.inspect}  #{Time.now}"
    params=YAML.load(activity.params)
    response=YAML.load(activity.response)
    if !activity.nil?
      activity.printed=true
      activity.print_credit_note(response) if params[:activitytype]==:credit_note
      activity.print_validation(response) if params[:activitytype]==:validation
      activity.save
    end
  end
end
