class Setting < ApplicationRecord
end
