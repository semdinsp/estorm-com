# All Administrate controllers inherit from this `Admin::ApplicationController`,
# making it the ideal place to put authentication logic or other
# before_actions.
#
# If you want to add pagination or other controller-level concerns,
# you're free to overwrite the RESTful controller actions.
module Admin
  class ApplicationController < Administrate::ApplicationController
    before_action :authenticate_user!
    before_action :authenticate_user!
    before_action do 
        redirect_to root_path, notice: "Need to be admin role" unless current_user && current_user.role=="admin"
    end
    
   # def authenticate_admin
  #    puts "current user is: #{current_user.inspect}"
  #    current_user.role=="admin"
  #  end
    
   

    # Override this value to specify the number of elements to display at a time
    # on index pages. Defaults to 20.
    # def records_per_page
    #   params[:per_page] || 20
    # end
  end
end
