class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  before_action :configure_permitted_parameters, if: :devise_controller?

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:name])
    devise_parameter_sanitizer.permit(:account_update, keys: [:name])
  end
  
  def cors_set_access_control_headers_DELETE
         headers['Access-Control-Allow-Origin'] = '*'
         headers['Access-Control-Allow-Methods'] = 'POST, PUT, DELETE, GET, PATCH, OPTIONS'
         headers['Access-Control-Request-Method'] = '*'
         headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
     end
  
  def destroy_item(item,redirect_location)
    item.destroy
    respond_to do |format|
      format.html { redirect_to redirect_location }
      format.json { head :no_content }
    end
  end
  def handle_error(item,format,action)
    format.html { render action: action}
    format.json { render json: item.errors, status: :unprocessable_entity }
  end
  def update_item(result,item)
    respond_to do |format|
      if result
        format.html { redirect_to item, notice: "#{item.class} was successfully updated." }
        format.json { head :no_content }
      else
         handle_error(item,format,'edit')
      end
    end
  end
  def create_item(item)
    respond_to do |format|
      if item.save
        format.html { redirect_to item, notice: "#{item.class }was successfully created."}
        format.json { render action: 'show', status: :created, location: item }
      else
         handle_error(item,format,'new')
      end
    end
  end
  

end
