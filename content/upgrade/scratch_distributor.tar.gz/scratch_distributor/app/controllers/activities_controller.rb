gem 'estorm_lotto_gem'
require 'estorm_lotto_gem'
class ActivitiesController < ApplicationController
  before_action :set_activity, only: [:show, :edit, :update, :destroy]
  before_action do 
      redirect_to user_session_path, notice: "Need to be signed in " unless current_user 
  end

  # GET /activities
  # GET /activities.json
  
  def index
    # @activities = Activity.all
    @activities=Activity.order('created_at DESC').page params[:page]
  end

  # GET /activities/1
  # GET /activities/1.json
  def show
  end

  # GET /activities/new
  def new
    @activity = Activity.new
  end

  # GET /activities/1/edit
  def edit
  end
  def set_language
    #gem 'i18n'
   # I18n::Backend::Simple.send(:include, I18n::Backend::Fallbacks)
  #  I18n.load_path=Dir[File.join(__FILE__, 'config/locales', '*.yml')]
   # puts "language file load path: #{Rails.root}  at: #{Dir[File.join(Rails.root, 'config/locales', '*.yml')].to_s}"
    #I18n.backend.load_translations
    I18n.locale = :en
    I18n.locale = Setting.first.locale.to_sym if !Setting.first.nil?
    puts "language locale set to: #{I18n.locale}"
  end
  
  def build_remote_url
    host=Setting.first.system_type
    baseurl="herokuapp.com/winners/winner_ajax_lookup"
    @remoteurl = "https://tms-laos.#{baseurl}" if host!='timor'
    @remoteurl = "https://tms-timor.#{baseurl}" if host=='timor'
  #  puts @remoteurl
    
  end
  
  def newvalidate
    @maxvirn=50
    @maxvirn=Setting.first.maxvirn   if !Setting.first.nil?
    setup_games
    set_language
    build_remote_url
    #cors_set_access_control_headers
  end
  
  def lottery
  
  end
  
  def validate
    @maxvirn=50
    @maxvirn=Setting.first.maxvirn   if !Setting.first.nil?
    setup_games
  end
  #START
  
 # def process_response(res)
#    failmsg=res.clone
#    failedcount=0
#   failedcount=res['failed'].size if !res['failed'].nil?
#    res['failedcount']=failedcount
#    wincount=0
#    wincount=res['winners'].size if !res['winners'].nil?
#    res['wincount']=wincount
  #  res.delete('failed')
  #  res.delete("list")
  #  failmsg.delete('winners')
  #  [failedcount,res,failmsg]
  # end
  
  def oldmultivalidate
    puts "params are #{params.inspect}"
  #  list=[]
  #  1.upto(params[:count].to_i) {   |count|
  #    list << {virn: params["virn#{count}"].to_s, serial: params["serial#{count}"].to_s} if !params["virn#{count}"].start_with?('enter')   
 #    }
     env=Rails.env
 #    env="production"
     
     virns=params.to_hash.clone
     
     ['authenticity_token','controller','commit','action','utf8'].each { |key| virns.delete(key)}
     virns.each { |v,k| # puts "v is #{v} k #{k}" 
              virns.delete(v) if k=="enter virn" }
     puts "virns: #{virns.inspect} params: #{params.inspect}"
     appname=Setting.first.system_type
     virns['appname']=appname
     @activity = Activity.new
     begin
       res=EstormLottoGem::MqttclientTms.mqtt_send_validation_message(appname,params["game"],virns.to_json.to_s,env)
       flash[:notice]=res.inspect.to_s
       @activity = Activity.new
       @activity.params=virns.to_yaml
       @activity.response=res.inspect.to_s
       @activity.user=current_user
       failedcount,res,failmsg=process_response(res)
       ['TMS Receipt Agent','TMS Receipt Operator'].each {  |title| 
           EstormLottoGem::MqttclientTms.tms_print(res.inspect.to_s, Hwid.systemid,title,Setting.first.logo,Setting.first.printer_type)
          }
     puts "multi v:  res is #{res.class}  fail: #{failmsg} inspect #{res.inspect}"
     if failedcount >0
       EstormLottoGem::MqttclientTms.tms_print_generic(failmsg.inspect.to_s, Hwid.systemid,"Failed VIRNs",Setting.first.logo,Setting.first.printer_type)
     end
     rescue Exception => e
        emsg="error: #{e.inspect}  res: #{res}"
        flash[:error]=emsg
        @activity.response=emsg
     
     end
     create_item(@activity)
    
  end


  
  #END

  # POST /activities
  # POST /activities.json
  def create 
    @activity = Activity.new(activity_params)
    create_item(@activity)
  end
  
  def print 
    puts "print #{params}"
    @activity = Activity.find(params[:id])
    Activity.print(@activity)
    render 'show'
  end

  # PATCH/PUT /activities/1
  # PATCH/PUT /activities/1.json
  def update
     update_item(@activity.update(activity_params),@activity)
   
  end

  # DELETE /activities/1
  # DELETE /activities/1.json
  def destroy
     destroy_item(@activity,activities_url)
  
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def setup_games
      games=['test']
      games=Setting.first.gamelist.split(',') if !Setting.first.nil?
      @games=[]
      games.each {|g|    @games<< [g,g]
          }
      @games
    end
    def set_activity
      @activity = Activity.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def activity_params
      params.require(:activity).permit(:params, :response, :printed, :user_id)
    end
end
