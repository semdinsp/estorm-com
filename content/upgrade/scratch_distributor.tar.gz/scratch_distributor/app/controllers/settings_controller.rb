class SettingsController < ApplicationController
  before_action :set_setting, only: [:show, :edit, :update, :destroy]
  before_action do 
      redirect_to user_session_path, notice: "Need to be signed in " unless current_user 
  end

  # GET /settings
  # GET /settings.json
  def index
    @settings = [Setting.first]
  end

  # GET /settings/1
  # GET /settings/1.json
  def show
  end

  # GET /settings/new
  def new
    @setting = Setting.new
  end

  # GET /settings/1/edit
  def edit
    @setting=Setting.first
  end

  def create 
    @setting = Setting.new(setting_params)
    create_item(@setting)
  end

  # PATCH/PUT /activities/1
  # PATCH/PUT /activities/1.json
  def update
     update_item(@setting.update(setting_params),@setting)   
  end

  # DELETE /activities/1
  # DELETE /activities/1.json
  def destroy
     destroy_item(@setting,settings_url)  
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_setting
      @setting = Setting.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def setting_params
      params.require(:setting).permit(:distributor_name, :scratch_service, :scantty, :lottery_service, :product_service, :system_type,:locale,:timezone, :printer_type, :maxvirn, :gamelist, :logo)
    end
end
