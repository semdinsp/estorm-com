Rails.application.routes.draw do
  resources :settings
  get "activities/validate"
  get "activities/newvalidate"
  post "activities/multivalidate"
  get "activities/lottery"
  #get "activities/print/:id" => "activities#print#:id" 
  get "activities/print"
   
  resources :activities
  namespace :admin do
    resources :users
    resources :activities
    resources :settings
    
    root to: "users#index"
  end
#  get "pages/about"
   mount ToolsEngine::Engine, at: "/commands"  
   mount ToolsValidator::Engine, at: "/validator"  
  root to: 'visitors#index'
  devise_for :users
  resources :users
end
