# set up terminal config
#Rails.application.session[:printer]="rongta"