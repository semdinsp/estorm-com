require 'rails_helper'

RSpec.describe Setting, type: :model do
 
  
 
    scenario 'setting creation' do
      s= FactoryBot.create(:setting, distributor_name: 'fred')
      expect(s.distributor_name).to eq('fred')
    
    
    end
  
  
end
