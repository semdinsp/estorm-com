require 'rails_helper'

RSpec.describe Activity, type: :model do
  
  scenario 'activity creation' do
    @user = User.new(email: 'user@example.com') 
    
    s= FactoryBot.create(:activity, params: 'fred',user: @user)
    expect(s.params).to eq('fred')
  
  
  end
  
end
