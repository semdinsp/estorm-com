Capybara.asset_host = 'http://localhost:3000'
