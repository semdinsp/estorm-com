FactoryBot.define do
  factory :setting do
    distributor_name { "MyString" }
  end
end
