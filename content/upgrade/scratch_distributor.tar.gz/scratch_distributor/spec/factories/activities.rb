FactoryBot.define do
  factory :activity do
    params {"MyText"}
    response { "MyText" }
    printed { false }
    user { nil }
  end
end
