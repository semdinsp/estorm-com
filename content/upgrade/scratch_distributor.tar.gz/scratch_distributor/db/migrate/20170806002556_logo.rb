class Logo < ActiveRecord::Migration[5.0]
  def change
    add_column :settings, :logo, :string, :default => "scratchlao"   #csv list of games
    add_column :settings, :printer_type, :string, :default => "rongta"   #csv list of games
    
  end
end
