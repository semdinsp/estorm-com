class Maxvirn < ActiveRecord::Migration[5.0]
  def change
    add_column :settings, :maxvirn, :integer, :default => 50
    
  end
end
