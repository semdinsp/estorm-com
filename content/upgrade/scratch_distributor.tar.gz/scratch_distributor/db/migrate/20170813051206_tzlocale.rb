class Tzlocale < ActiveRecord::Migration[5.0]
  def change
    
    add_column :settings, :locale, :string, :default => "en"   #csv list of games
    add_column :settings, :timezone, :string, :default => "Asia/Dili"   #csv list of games
    
    
  end
end
