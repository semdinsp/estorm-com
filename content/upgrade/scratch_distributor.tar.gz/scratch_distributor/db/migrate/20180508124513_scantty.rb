class Scantty < ActiveRecord::Migration[5.1]
  def change
    add_column :settings, :scantty, :string, :default =>  'ttyUSB0'
    
  end
end
