class Settingservices < ActiveRecord::Migration[5.1]
  def change
    add_column :settings, :scratch_service, :boolean, :default => true
    add_column :settings, :lottery_service, :boolean, :default => false
    add_column :settings, :products_service, :boolean, :default => false
    
    
  end
end
