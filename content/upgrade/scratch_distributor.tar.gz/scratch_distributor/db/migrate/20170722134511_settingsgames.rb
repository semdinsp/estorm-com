class Settingsgames < ActiveRecord::Migration[5.0]
  def change
    add_column :settings, :gamelist, :string, :default => ""   #csv list of games
    
  end
end
